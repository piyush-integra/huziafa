<!-- Order Details Section -->

<?php include( 'order_details_section.php' ); ?>

<!-- Billing & Shipping Details Section -->

<?php include( 'order_bs_section.php' ); ?>

<!-- Order Items Section -->

<?php include( 'order_items_section.php' ); ?>

<!-- Order Notes Section -->

<?php include( 'order_notes_section.php' ); ?>