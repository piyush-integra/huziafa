<?php
function pmwi_admin_head(){
	?>
	<script type="text/javascript">
		var woo_addon_free_edition = '<?php echo PMWI_EDITION; ?>';
	</script>
	<?php
}